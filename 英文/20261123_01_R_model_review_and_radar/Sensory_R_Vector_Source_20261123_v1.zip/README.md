# R重绘图与数据

- 合并图册：Sensory_R_Figures_Complete_20261123.pdf（16页，可用书签跳转）。
- 全部单体强度响应：figures/01、02。
- 模型对照：figures/03；说明见Model_Review_and_Figure_Notes.md。
- 单体属性雷达图：figures/04，全部15种；独立面板见figures/single_radar_panels。
- 混合属性雷达图：figures/05，全部65样；六个单高水平预览见figures/06。
- 单体雷达图统一刻度版：figures/07。
- R源代码：replot_sensory.R；输入为inputs中的逐人记录；计算结果位于tables。
- 汇总均值待核查：Mean_Check_Items.csv。

所有雷达值均为属性选择比例。缺失记录未填零。原始Excel未修改。
